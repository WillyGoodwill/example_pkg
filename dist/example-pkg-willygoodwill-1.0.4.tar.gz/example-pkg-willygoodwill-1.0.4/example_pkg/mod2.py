def clean_data():
    print('clean data with mod2.py')

class Location:
    pass

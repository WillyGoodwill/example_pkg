# Example Package

This is a simple example project. The goal of this project is to deliver Ikea price list. In order to do this the package parses ikea products and combine them all to the ultimate list with prices. You can find the full code here 

[Github code](https://github.com/WillyGoodwill/example_pkg).

# Console Usage
Type in console

`python3 -m example_pkg`

# Python Editor Usage
Type in python editor

`from example_pkg.mod1 import *`
`Furniture().parsing()`



alist = ['one','two','three']

import example_pkg.mod1, example_pkg.mod2
__all__=['mod1','mod2']
__version__ = '1.0.4'